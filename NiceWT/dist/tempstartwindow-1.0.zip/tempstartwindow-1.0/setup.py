from distutils.core import setup

setup(name='tempstartwindow',
      version='1.0',
      py_modules=['StartWindow']
      )
