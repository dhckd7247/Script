from distutils.core import setup

setup(name='NiceWT',
      version='1.0',
      py_modules=['StartWindow']
      )
